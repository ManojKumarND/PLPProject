package com.insurance.claim.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.insurance.claim.Connect;
import com.insurance.claim.bean.CreateClaimBean;
import com.insurance.claim.bean.UserNameBean;
import com.insurance.claim.service.CreateClaimService;

public class CreateClaimController extends HttpServlet {
	
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		//response.setContentType("text/html");
		RequestDispatcher rd=null;
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String user=null;
		CreateClaimBean claimbean=new CreateClaimBean();
		CreateClaimService ccservice=new CreateClaimService();
		UserNameBean userbean=new UserNameBean();

		//con=Connect.getconnect();
		String cname=request.getParameter("custname");
		String reason=request.getParameter("reason");
		 String location=request.getParameter("location");
		 String city=request.getParameter("city");
		 String state=request.getParameter("state");
		 int zip=Integer.parseInt(request.getParameter("zip"));
		 String type=request.getParameter("domain");
		 
		// System.out.println(userbean.getUsername());
		 HttpSession session1=request.getSession(false);
			 user=(String)session1.getAttribute("user");
			 
			 System.out.println("http:"+user);
			 UserNameBean unb=new UserNameBean();
			 unb.setUsername(user);
		 claimbean.setReason(reason);
		 claimbean.setLocation(location);
		 claimbean.setCity(city);
		 claimbean.setState(state);
		 claimbean.setZip(zip);
		 claimbean.setType(type);
		 
		try {
		int updateResult=0;
		
		 HttpSession session10=request.getSession(false);
		 String rolec=(String)session10.getAttribute("role");
		 
		 System.out.println("Createclaim controller rolec : "+rolec);
		 if(rolec.equals("Agent"))
		 {
			 HttpSession session9=request.getSession(false);
		 String customername=(String)session9.getAttribute("agentcustomer");
		System.out.println("Customer : "+customername);
			 updateResult=ccservice.createClaim(claimbean,customername);
		 }
		 else if(rolec.equals("Admin"))
		 {
			 updateResult=ccservice.createClaim(claimbean,cname);
		 }
		 else {
		updateResult=ccservice.createClaim(claimbean,user);
		 }
		System.out.println("controller : "+updateResult);
		
		if(updateResult==1)
		{
			request.getRequestDispatcher("/claimquestions.jsp").include(request, response);
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			}
			}
}
